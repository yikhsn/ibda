<?php $__env->startSection('title'); ?>
  <title>Qur'anKu</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="search-surat-container-show">
    <div class="search-box">
      <div class="logo-quran-box">
        <img class="logo-quran" src="<?php echo e(asset('/img/logo-white.png')); ?>" alt="">
      </div>
      <form action="/surat/cari" method="POST">
        <?php echo e(csrf_field()); ?>


        <input class="search-input" name="query" type="text" placeholder="Cari berdasarkan nama surah atau arti ayat...">
        <button type="submit" class="search-button">
          Cari
        </button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>