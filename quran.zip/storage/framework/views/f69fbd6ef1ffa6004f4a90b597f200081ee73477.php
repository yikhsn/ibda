<?php $__env->startSection('title'); ?>
    <title>List Surat - Qur'anKu</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        

    <div class="search-surat-container">
      <div class="search-box">
        <div class="logo-quran-box">
          <img class="logo-quran" src="<?php echo e(asset('/img/logo-white.png')); ?>" alt="">
        </div>
        
      </div>
    </div>

    <div class="content-surat">
      <div class="navbar-surat">
          <a href="/">SURAH</a>
      </div>
      
      <div class="row no-gutters surats">
        <?php $__currentLoopData = $surats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/surat/<?php echo e($surat->nomor_surat); ?>" class="col-md-6 col-12 surat-single-box">
          <div class="row surat-single">
            <div class="col-1 nomor-surat">
              <?php echo e($surat->nomor_surat); ?>

            </div>
            <div class="col-5">
              <div class="nama-surat"><?php echo e($surat->nama_surat); ?></div>
              <div class="arti-nama-surat"><?php echo e($surat->arti_nama); ?></div>
            </div>
            <div class="col-5">
              <div class="nama-surat-arab"><?php echo e($surat->nama_surat_arab); ?></div>
            </div>
          </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>