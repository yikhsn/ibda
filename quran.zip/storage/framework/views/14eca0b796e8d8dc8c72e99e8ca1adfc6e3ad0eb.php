<?php $__env->startSection('title'); ?>
    <title>Qur'anKu - Aplikasi Alquran Digital</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header>
        <div class="header-box">
            <div class="header-box__logo">
                <img src="img/logo.png" alt="" srcset="" class="logo">
            </div>

            <div class="header-box__button">
                <a href="/surat" class="button button-animated button-animated-left header-button__read">
                    Baca Qur'an
                </a>
                <a href="/surat/cari" class="button button-animated button-animated-right header-button__read">
                    Cari Surat
                </a>
                
                
                    <a href="/hafalan" class="button button-animated button-animated-left header-button__read">
                        Mode Hafalan
                    </a>
                
            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>