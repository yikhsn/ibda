<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>

  <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">

  <!-- Styles -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/animated.css">
</head>
<body>
  
  
  <p><?php echo e($juz->nomor_juz); ?></p>

  <ul>
      <?php $__currentLoopData = $juz->ayats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <div>
          <?php echo e($ayat->nomor_ayat); ?>

          <?php echo e($ayat->teks_arab); ?>

          <?php echo e($ayat->teks_latin); ?>

          <?php echo e($ayat->terjemahan_idn); ?>

          <?php echo e($ayat->terjemahan_eng); ?>

         </div>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

</html>