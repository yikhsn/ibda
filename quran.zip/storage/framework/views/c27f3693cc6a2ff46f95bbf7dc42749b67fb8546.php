<?php $__env->startSection('title'); ?>
  <title></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <nav class="navbar navbar-expand-lg navbar-light">
      <a class="navbar-brand" href="/"><i class="fa fa-home"></i></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" id="suratDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Pindah ke Surat
              <span class="caret"></span>
            </a>
            <div class="dropdown-menu scrollable-menu" aria-labelledby="suratDropdown" role="menu">
                <?php $__currentLoopData = $all_surats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
                  <a class="dropdown-item" href="/surat/<?php echo e($surat_current->nomor_surat); ?>"><?php echo e($surat_current->nama_surat); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" id="ayatDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Pindah ke Ayat<span class="caret"></span>
            </a>
            <div class="dropdown-menu scrollable-menu" aria-labelledby="ayatDropdown" role="menu">
                <?php $__currentLoopData = $surat->ayats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
                  <a class="dropdown-item" href="#<?php echo e($ayat->nomor_ayat); ?>"><?php echo e($ayat->nomor_ayat); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </li>
        </ul>

       <!--  <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="cari surah, ayat, arti..." aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">cari</button>
        </form> -->
      </div>
    </nav>

    <div class="keterangan-surat-container">
      <div class="keterangan-surat">
          <div class="keterangan-surat-nama-arab"> <?php echo e($surat->nama_surat_arab); ?> </div>

          <div class="keterangan-surat-nama-indo"><?php echo e($surat->nama_surat); ?></div>
          <div class="keterangan-surat-arti-nama"><?php echo e($surat->arti_nama); ?></div>        
      </div>
    </div>

    <div class="row no-gutters body-ayats-container">
      <div class="body-ayats">
        <?php $__currentLoopData = $surat->ayats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <div id="<?php echo e($ayat->nomor_ayat); ?>" class="single-ayat">
          <div class="single-ayat-kiri">
            <div class="ayat-nomor-surat">
                <?php echo e($ayat->nomor_ayat); ?>

            </div>
            
            <div class="ayat-share">
              <div class="ayat-share-twitter">
                  <a target="_blank" href="https://twitter.com/share?ref_src=surat/<?php echo e($surat->nomor_surat); ?>" data-show-count="false"><img src="<?php echo e(URL::asset('img/twitter.svg')); ?>" alt=""></a>
              </div>
              <div class="ayat-share-facebook">
                  <a target="_blank" href="http://www.facebook.com/sharer.php?u=surat/<?php echo e($surat->nomor_surat); ?>"><img src="<?php echo e(URL::asset('img/facebook.svg')); ?>" alt=""></a>

              </div>
            </div>
          </div>
          <div class="single-ayat-kanan">
            <div class="ayat-teks-arab">
                <?php echo e($ayat->teks_arab); ?>

            </div>
            <div class="ayat-terjemahan">
              <?php echo e($ayat->terjemahan_idn); ?>

            </div>
          </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- <button type="button" class="btn btn-outline-light" margin="20"><i class="fa fa-arrow-left"></i> Surah Sebelumnya</button>
        <button type="button" class="btn btn-outline-light">Surah Berikutnya <i class="fa fa-arrow-right"></i></button> -->

      </div>
    </div>

  <script>
    var musik = new Audio();
      
    musik.src = "<?php echo e(URL::asset('mp3/1.mp3')); ?>";
    musik.loop = true;
    // musik.play(); 
    
    function mulaiAudio(){
      var play = document.querySelector(".ayat-suara-button");

      play.addEventListener('click', fplay);

      function fplay() {
        if(musik.paused){
          musik.play();
          play.style.background = "url('../img/pause.svg')";
        }
        else {
          musik.pause();
          play.style.background = "url('../img/play.svg')";
        }
      }
    }

    window.addEventListener('load', mulaiAudio);
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>